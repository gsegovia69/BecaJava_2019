package com.carrot.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.carrot.entities.AsignaturaEntity;
import com.carrot.entities.ProfesorEntity;

public interface AsignaturaRepository extends CrudRepository<AsignaturaEntity, Long> {

	@Query(value="select p from AsignaturaEntity p where p.nombre like %?1%")
	List<AsignaturaEntity> findByCriteria(@Param("criterioBusqueda") String parametroDeBusqueda);

}
