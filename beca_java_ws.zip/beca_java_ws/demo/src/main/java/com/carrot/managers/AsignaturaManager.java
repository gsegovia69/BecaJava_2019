package com.carrot.managers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carrot.dto.AsignaturaDTO;
import com.carrot.entities.AlumnoEntity;
import com.carrot.entities.AsignaturaEntity;
import com.carrot.repositories.AsignaturaRepository;

@Service
public class AsignaturaManager {

	@Autowired
	private AsignaturaRepository repository;

	public AsignaturaRepository getRepository() {
		return repository;
	}

	public List<AsignaturaDTO> dameAsignaturas() {
		List<AsignaturaDTO> dtoList = new ArrayList<>();
		repository.findAll().forEach(asignaturaEntity -> {
			dtoList.add(convertirEntityaDTO(asignaturaEntity));
		});
		
//		StreamSupport.stream(repository.findAll().spliterator(),false).filter(asignaturaEntity -> asignaturaEntity.getIdClase()==1).forEach(asignaturaEntity -> {
//			dtoList.add(convertirEntityaDTO(asignaturaEntity));
//		});
		
		return dtoList;
	}

	public List<AsignaturaDTO> dameAsignaturas(String criterio) {
		List<AsignaturaDTO> dtoList = new ArrayList<>();
		repository.findByCriteria(criterio).forEach(asignaturaEntity -> {
			dtoList.add(convertirEntityaDTO(asignaturaEntity));
		});
		
		return dtoList;
	}
	
	
	
	public AsignaturaDTO dameAsignatura(Long id) {
		return convertirEntityaDTO(repository.findById(id).orElse(new AsignaturaEntity()));
	}
	
	public AsignaturaDTO guardamelo(AsignaturaDTO dto) {
		return convertirEntityaDTO(repository.save(convertirDTOaEntity(dto)));
	}
	
	public void borrar(Long id) {
		/*
		AsignaturaEntity entity = new AsignaturaEntity();
		entity.setId(id);
		repository.delete(entity);
		*/
		repository.deleteById(id);
	}

	private AsignaturaDTO convertirEntityaDTO(AsignaturaEntity entity) {
		AsignaturaDTO dto = new AsignaturaDTO();
		dto.setId(entity.getId());
		dto.setNombre(entity.getNombre());
		dto.setOrden(entity.getOrden());
		dto.setIdCurso(entity.getIdClase());
		return dto;		
	}

	private AsignaturaEntity convertirDTOaEntity(AsignaturaDTO dto) {
		AsignaturaEntity entity = new AsignaturaEntity();
		Long id = (dto.getId() != null)?dto.getId():0L;
		entity.setId(id);
		entity.setNombre(dto.getNombre());
		entity.setOrden(dto.getOrden());
		entity.setIdClase(dto.getIdCurso());
		return entity;		
	}
}
