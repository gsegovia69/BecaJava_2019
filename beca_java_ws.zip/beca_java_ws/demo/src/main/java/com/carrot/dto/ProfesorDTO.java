package com.carrot.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProfesorDTO {

	private Long id;
	
	private String nombre;
	private String apellidos;
	private String email;
	private String ciudad;

	private Long idClase;
}