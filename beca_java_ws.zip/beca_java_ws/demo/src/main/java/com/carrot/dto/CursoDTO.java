package com.carrot.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CursoDTO {

	private Long id;
	
	private String nombre;
}