package com.carrot.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;

import com.carrot.entities.AsignaturaEntity;
import com.carrot.entities.ProfesorEntity;

public interface ProfesorRepository extends Repository<ProfesorEntity, String> {

	void delete(ProfesorEntity asignatura);

	List<ProfesorEntity> findAll();


	ProfesorEntity save(ProfesorEntity asignatura);
	
	@Query(value="select p from profesor p where p.nombre = ?1 or p.apellidos = ?2 order by p.nombre asc, p.apellidos.desc", 
			nativeQuery = true)
	List<ProfesorEntity> metodo1(String parametroDeBusqueda1, String parametroDeBusqueda2);

	@Query(value="select p from ProfesorEntity p where p.email = :email and p.ciudad = :ciudad")
	List<ProfesorEntity> metodo2(@Param("ciudad") String parametroDeBusqueda2, @Param("email") String parametroDeBusqueda1);

	@Query(value="select p from ProfesorEntity p where p.nombre like %?1%")
	List<ProfesorEntity> findByCriteria(@Param("criterioBusqueda") String parametroDeBusqueda);

}
