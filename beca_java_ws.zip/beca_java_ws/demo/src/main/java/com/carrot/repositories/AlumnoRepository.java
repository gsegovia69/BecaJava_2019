package com.carrot.repositories;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.carrot.entities.AlumnoEntity;
import com.carrot.entities.AsignaturaEntity;
import com.carrot.entities.ProfesorEntity;


public interface AlumnoRepository extends CrudRepository<AlumnoEntity, Long> {

	// SELECT * FROM ALUMNO WHERE NOMBRE = 'name' ORDER BY APELLIDOS ASC
	public List<AlumnoEntity> findAllByNombreOrderByApellidosAsc(String name);
	
	// SELECT * FROM ALUMNO WHERE NOMBRE = 'name' AND APELLIDOS = 'apellidos'ORDER BY APELLIDOS ASC
	public List<AlumnoEntity> findAllByNombreAndApellidosOrderByApellidosAsc(String name, String apellidos);
	
	// SELECT * FROM ALUMNO WHERE NOMBRE = 'name' OR APELLIDOS = 'apellidos' OR CIUDAD = 'ciudad' ORDER BY EMAIL ASC
	public List<AlumnoEntity> findAllByNombreOrApellidosOrCiudadOrderByEmailAsc(String name, String apellidos, String ciudad);
	
	// SELECT * FROM ALUMNO ORDER BY NOMBRE DESC
	public List<AlumnoEntity> findAll();
	
	@Query(value="select p from AlumnoEntity p order by p.nombre")
	Page<AlumnoEntity> findPageOrderByName(Pageable pageable);
	
	@Query(value="select p from AlumnoEntity p order by p.nombre DESC")
	Page<AlumnoEntity> findPageOrderByNameDescending(Pageable pageable);

	@Query(value="select p from AlumnoEntity p order by p.id")
	Page<AlumnoEntity> findAllOrderById(Pageable pageable);
	//List<AlumnoEntity> findAllOrderById(int pagina,int pageSize);
	
	@Query(value="select p from AlumnoEntity p order by p.id DESC")
	Page<AlumnoEntity> findAllOrderByIdDescending(Pageable pageable);

	@Query(value="select p from AlumnoEntity p where p.nombre like %?1%")
	List<AlumnoEntity> findByCriteria(@Param("criterioBusqueda") String parametroDeBusqueda);
	
	@Query(value="select count(*) from AlumnoEntity")
	Double getCount();

	@Query(value="select p from AlumnoEntity p order by p.nombre")
	List<AlumnoEntity> findAllOrderByName();
	
	@Query(value="select p from AlumnoEntity p order by p.nombre DESC")
	List<AlumnoEntity> findAllOrderByNameDescending();
}
