package com.carrot.managers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carrot.dto.AsignaturaDTO;
import com.carrot.dto.CursoDTO;
import com.carrot.entities.AsignaturaEntity;
import com.carrot.entities.CursoEntity;
import com.carrot.repositories.CursoRepository;

@Service
public class CursoManager {

	@Autowired
	private CursoRepository repository;
	
	public CursoRepository getRepository() {
		return repository;
	}
	
	public List<CursoDTO> dameCursos(){
		List<CursoDTO> dtoList = new ArrayList<>();
		repository.findAll()
			.forEach(entity -> dtoList.add(transformEntity(entity)));
		return dtoList;
	}
	
	public CursoDTO giveMeOneCurso(Long idCurso) {
		return transformEntity(repository.findById(idCurso).orElse(new CursoEntity()));
	}
	
	private CursoDTO transformEntity(CursoEntity entity) {
		CursoDTO dto = new CursoDTO();
		dto.setId(entity.getId());
		dto.setNombre(entity.getNombre());
		return dto;
	}
	
	public CursoDTO guardamelo(CursoDTO dto) {
		return convertirEntityaDTO(repository.save(convertirDTOaEntity(dto)));
	}
	
	private CursoDTO convertirEntityaDTO(CursoEntity entity) {
		CursoDTO dto = new CursoDTO();
		dto.setId(entity.getId());
		dto.setNombre(entity.getNombre());
		return dto;		
	}
	
	private CursoEntity convertirDTOaEntity(CursoDTO dto) {
		CursoEntity entity = new CursoEntity();
		Long id = (dto.getId() != null)?dto.getId():0L;
		entity.setId(id);
		entity.setNombre(dto.getNombre());
		return entity;		
	}
	
}
