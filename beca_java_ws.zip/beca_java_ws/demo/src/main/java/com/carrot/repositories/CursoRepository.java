package com.carrot.repositories;

import org.springframework.data.repository.CrudRepository;

import com.carrot.entities.CursoEntity;

public interface CursoRepository extends CrudRepository<CursoEntity, Long> {

}
