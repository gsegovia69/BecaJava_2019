package com.carrot.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CriterioBusqueda {

	private String criterio;
	
}
