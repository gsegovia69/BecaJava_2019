package com.carrot.managers;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.carrot.dto.AlumnoDTO;
import com.carrot.dto.AsignaturaDTO;
import com.carrot.entities.AlumnoEntity;
import com.carrot.entities.CursoEntity;
import com.carrot.repositories.AlumnoRepository;
import com.carrot.repositories.CursoRepository;


@Service
public class AlumnoManager {

	@Autowired
	private AlumnoRepository repository;
	
	private CursoRepository cursoRepository;
	
	public AlumnoRepository getRepository() {
		return repository;
	}
	
	public CursoRepository getCursoRepository() {
		return cursoRepository;
	}

	public List<AlumnoDTO> dameAlumnos(int order, int direction,int pagina,int pageSize){
		List<AlumnoDTO> dtoList = new ArrayList<>();
		Page<AlumnoEntity> entList=null;
		
		Pageable pageable = PageRequest.of(pagina-1,pageSize);

		if(order==1 && direction==0)			
			entList=repository.findAllOrderById(pageable);
		else if(order==1)
			entList=repository.findAllOrderByIdDescending(pageable);
			//entList=repository.findAllOrderByIdDescending(pagina,pageSize);
		else if(order==2 && direction==0)
			entList=repository.findPageOrderByName(pageable);
		else if(order==2)
			entList=repository.findPageOrderByNameDescending(pageable);
		
		entList.forEach(entity -> {
				dtoList.add(transformEntity(entity,"test"));	
			});
		
		return dtoList;
	}
	
	public Integer getTotalPages(int pageSize)
	{
		return pageSize>0 ? (int) Math.ceil(repository.getCount()/(double) pageSize) : 0;
	}
	
	public List<AlumnoDTO> dameAlumnos(String criterio){
		List<AlumnoDTO> dtoList = new ArrayList<>();
		repository.findByCriteria(criterio).forEach(alumnoEntity -> {
			dtoList.add(transformEntity(alumnoEntity,"test"));
		});

		return dtoList;
	}

	private AlumnoDTO transformEntity(AlumnoEntity entity, String clase) {
		AlumnoDTO dto = new AlumnoDTO();
		dto.setId(entity.getId());
		dto.setNombre(entity.getNombre());
		dto.setApellidos(entity.getApellidos());
		dto.setEmail(entity.getEmail());
		dto.setCiudad(entity.getCiudad());
		dto.setPhotoUri(entity.getPhotoUri());
	
		dto.setNombreClase(clase);
		return dto;
	}

	public Integer getFirstPageFromIndex(int direction, char indice,int pageSize) {
		List<AlumnoEntity> entList = new ArrayList<>();

		if(direction==0)
			entList=repository.findAllOrderByName();
		else
			entList=repository.findAllOrderByNameDescending();
		
		int i=1;
		for(int j=1; j<entList.size(); j++)
			if(entList.get(j).getNombre().startsWith(String.valueOf(indice))) break;
			else i++;
		
		if(i>=entList.size()) i=1;
		
		return pageSize>0 ? (int) Math.ceil(i/(double) pageSize) : 0;
		
	}

}
