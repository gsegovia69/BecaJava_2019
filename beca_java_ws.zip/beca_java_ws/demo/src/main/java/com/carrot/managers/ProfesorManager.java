package com.carrot.managers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carrot.dto.AlumnoDTO;
import com.carrot.dto.ProfesorDTO;
import com.carrot.entities.AlumnoEntity;
import com.carrot.entities.ProfesorEntity;
import com.carrot.repositories.CursoRepository;
import com.carrot.repositories.ProfesorRepository;

@Service
public class ProfesorManager {
	@Autowired
	private ProfesorRepository repository;
	
	public ProfesorRepository getRepository() {
		return repository;
	}
	
	public List<ProfesorDTO> dameProfesores(){
		List<ProfesorDTO> dtoList = new ArrayList<>();
		repository.findAll()
			.forEach(entity -> dtoList.add(transformEntity(entity)));
		return dtoList;
	}
	
	public List<ProfesorDTO> dameProfesores(String criterio){
		List<ProfesorDTO> dtoList = new ArrayList<>();
		repository.findByCriteria(criterio)
			.forEach(entity -> dtoList.add(transformEntity(entity)));
		return dtoList;
	}

	public List<ProfesorDTO> metodoConElNombreQueNoQuieras(ProfesorDTO dto){
		List<ProfesorDTO> dtoList = new ArrayList<ProfesorDTO>();
		List<ProfesorEntity> entiytList = repository.metodo1(dto.getNombre(), dto.getApellidos());
		for(ProfesorEntity entity : entiytList) {
			ProfesorDTO auxDTO = convertirProfesorEntity_A_DTO(entity);
			dtoList.add(auxDTO);
		}
		return dtoList;
	}
	
	public List<ProfesorDTO> metodoConElNombreQueQuieras(String email, String ciudad){
		List<ProfesorDTO> dtoList = new ArrayList<ProfesorDTO>();
		List<ProfesorEntity> entiytList = repository.metodo2(ciudad, email);
		for(ProfesorEntity entity : entiytList) {
			ProfesorDTO auxDTO = convertirProfesorEntity_A_DTO(entity);
			dtoList.add(auxDTO);
		}
		return dtoList;
	}

	private ProfesorDTO convertirProfesorEntity_A_DTO(ProfesorEntity entity) {
		ProfesorDTO dto = new ProfesorDTO();
		dto.setId(entity.getId());
		dto.setNombre(entity.getNombre());
		//ETC...
		return dto;
	}
	
	private ProfesorDTO transformEntity(ProfesorEntity entity) {
		ProfesorDTO dto = new ProfesorDTO();
		dto.setId(entity.getId());
		dto.setNombre(entity.getNombre());
		return dto;
	}
	
}
