package com.carrot;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.carrot.dto.AlumnoDTO;
import com.carrot.dto.AsignaturaDTO;
import com.carrot.dto.CriterioBusqueda;
import com.carrot.dto.CursoDTO;
import com.carrot.dto.ProfesorDTO;
import com.carrot.managers.AlumnoManager;
import com.carrot.managers.AsignaturaManager;
import com.carrot.managers.CursoManager;
import com.carrot.managers.ProfesorManager;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Controller
public class HomeController {

	private String mensaje;
	@Autowired
	private AsignaturaManager asignaturaManager;

	@Autowired
	private CursoManager cursoManager;

	@Autowired
	private AlumnoManager alumnoManager;

	@Autowired
	private ProfesorManager profesorManager;

	@GetMapping("/")
	public String Home() {
		return "home";
	}
	
	@GetMapping("/buscar")
	public String Buscar(Model model) {
		model.addAttribute("criterio", new CriterioBusqueda());
		return "buscador";
	}

	@PostMapping("/buscar")
	public String Buscar(@RequestParam String criterio, Model model) {
		List<AsignaturaDTO> listaAsignaturas = asignaturaManager.dameAsignaturas(criterio);
		model.addAttribute("listaAsignaturas", listaAsignaturas);

		List<AlumnoDTO> listaAlumnos = alumnoManager.dameAlumnos(criterio);
		model.addAttribute("listaAlumnos", listaAlumnos);
		
		List<ProfesorDTO> listaProfesores = profesorManager.dameProfesores(criterio);
		model.addAttribute("listaProfesores", listaProfesores);
		
		model.addAttribute("criterio", new CriterioBusqueda());
		return "resultadoBusqueda";
	}

	@GetMapping("/listaAsignaturas")
	public String listaAsignaturas(Model model) {
		List<AsignaturaDTO> listaAsignaturas = asignaturaManager.dameAsignaturas();
		model.addAttribute("listaAsignaturas", listaAsignaturas);
		return "listaAsignaturas";
	}

	@GetMapping("/editarAsignatura")
	public String editarAsignatura(@RequestParam Long identificador, Model model) {
		AsignaturaDTO asignatura = asignaturaManager.dameAsignatura(identificador);
		asignatura.setListaCursos(cursoManager.dameCursos());
		model.addAttribute("asignatura", asignatura);		
		return "editarAsignatura";
	}
	
	@PostMapping("/saveAsignatura")
	public String editAsignatura(@Valid AsignaturaDTO asignatura, Model model) {
		establecerMensaje(null);
		asignaturaManager.guardamelo(asignatura);
		establecerMensaje("Asignatura guardada correctamente");
		model.addAttribute("mensaje", mensaje);
		return "redirect:/listaAsignaturas";
	}
	
	@GetMapping("/nuevaAsignatura")
	public String newAsignatura(Model model) {
		AsignaturaDTO asignatura = new AsignaturaDTO();
		asignatura.setListaCursos(cursoManager.dameCursos());
		model.addAttribute("asignatura", asignatura);		
		return "editarAsignatura";
	}

	@GetMapping("/borrarAsignatura")
	public String borrarAsignatura(@RequestParam Long identificador,Model model) {
		establecerMensaje(null);
		asignaturaManager.borrar(identificador);
		establecerMensaje("Asignatura eliminada correctamente");
		model.addAttribute("mensaje", mensaje);
		return "redirect:/listaAsignaturas";
	}
	
	@GetMapping("/listaClases")
	public String listaClases(Model model) {
		List<CursoDTO> listaClases = cursoManager.dameCursos();
		model.addAttribute("listaClases", listaClases);
		return "listaClases";
	}

	@GetMapping("/editarClase")
	public String editarClase(@RequestParam Long identificador, Model model) {
		CursoDTO curso = cursoManager.giveMeOneCurso(identificador);
		model.addAttribute("curso", curso);		
		return "editarCurso";
	}

	@PostMapping("/saveCurso")
	public String editCurso(@Valid CursoDTO curso, Model model) {
		establecerMensaje(null);
		cursoManager.guardamelo(curso);
		establecerMensaje("Curso guardado correctamente");
		model.addAttribute("mensaje", mensaje);
		return "redirect:/listaClases";
	}

	@GetMapping("/nuevaClase")
	public String newCurso(Model model) {
		CursoDTO curso = new CursoDTO();
		model.addAttribute("curso", curso);		
		return "editarCurso";
	}

	@GetMapping("/listaAlumnos")
	public String listaAlumnos(Model model,@RequestParam(value="order", defaultValue = "1") Integer order, 
					@RequestParam(value = "direction", defaultValue = "0") Integer direction,
					@RequestParam(value = "pagina", defaultValue = "1") Integer pagina,
					@RequestParam(value = "indice", defaultValue = "*") char indice,
					@RequestParam(value = "view", defaultValue = "1") Integer view,
					@RequestParam(value = "pageSize", defaultValue = "8") Integer pageSize) {

		if(indice!='*') pagina=alumnoManager.getFirstPageFromIndex(direction,indice,pageSize);
		
		List<AlumnoDTO> listaAlumnos = alumnoManager.dameAlumnos(order,direction,pagina,pageSize);
		int totalPages=alumnoManager.getTotalPages(pageSize);

		model.addAttribute("listaAlumnos", listaAlumnos);
		model.addAttribute("order", order);
		model.addAttribute("direction", direction);
		model.addAttribute("pagina", pagina);
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("indice", indice);
		model.addAttribute("view", view);
		model.addAttribute("pageSize", pageSize);

		return "listaAlumnos";
	}

	@GetMapping("/listaProfesores")
	public String listaProfesores(Model model) {
		List<ProfesorDTO> listaProfesores = profesorManager.dameProfesores();
		model.addAttribute("listaProfesores", listaProfesores);
		
		return "listaProfesores";
	}

	private void establecerMensaje(String texto) {
		if(texto == null) {
			mensaje = "";
		}else {
			
			mensaje = texto;
		}
	}
}
