package io.spring.billing.entities;

public interface BillingEntity {

    Long getId();

}
