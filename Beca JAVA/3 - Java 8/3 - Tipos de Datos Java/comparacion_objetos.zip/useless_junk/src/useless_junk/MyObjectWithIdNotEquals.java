package useless_junk;

public class MyObjectWithIdNotEquals {

	private Integer id;

	public MyObjectWithIdNotEquals(Integer id) {
		super();
		this.id = id;
	}

}
